<script>
  let { person = null, onSave = () => {}, onDelete = () => {}, onClose = () => {} } = $props();

  let name = $state(person?.name ?? "");
  let note = $state(person?.note ?? "");
  let color = $state(person?.color ?? "#3b82f6");

  // Felder neu befüllen, wenn eine andere Person ausgewählt wird
  $effect(() => {
    name = person?.name ?? "";
    note = person?.note ?? "";
    color = person?.color ?? "#3b82f6";
  });

  const colors = ["#3b82f6", "#ef4444", "#22c55e", "#f59e0b", "#a855f7", "#ec4899", "#14b8a6"];

  function submit() {
    if (!name.trim()) return;
    onSave({ id: person?.id, name: name.trim(), note: note.trim() || null, color });
  }
</script>

<div class="panel">
  <h3>{person ? "Person bearbeiten" : "Neue Person"}</h3>

  <label>
    Name
    <input type="text" bind:value={name} placeholder="z.B. Hannah" />
  </label>

  <label>
    Notiz
    <textarea bind:value={note} placeholder="optional" rows="3"></textarea>
  </label>

  <div class="color-row">
    {#each colors as c}
      <button
        type="button"
        class="swatch"
        class:active={color === c}
        style="background:{c}"
        onclick={() => (color = c)}
        aria-label="Farbe wählen"
      ></button>
    {/each}
  </div>

  <div class="actions">
    <button class="primary" onclick={submit}>Speichern</button>
    {#if person}
      <button class="danger" onclick={() => onDelete(person.id)}>Löschen</button>
    {/if}
    <button onclick={onClose}>Abbrechen</button>
  </div>
</div>

<style>
  .panel {
    display: flex;
    flex-direction: column;
    gap: 0.75rem;
    padding: 1rem;
    background: white;
    border-radius: 8px;
    box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
  }
  h3 {
    margin: 0;
    font-size: 1rem;
  }
  label {
    display: flex;
    flex-direction: column;
    gap: 0.25rem;
    font-size: 0.85rem;
    color: #475569;
  }
  input,
  textarea {
    padding: 0.5rem;
    border: 1px solid #cbd5e1;
    border-radius: 6px;
    font-size: 0.9rem;
    font-family: inherit;
  }
  .color-row {
    display: flex;
    gap: 0.4rem;
  }
  .swatch {
    width: 28px;
    height: 28px;
    border-radius: 50%;
    border: 2px solid transparent;
    cursor: pointer;
  }
  .swatch.active {
    border-color: #1f2937;
  }
  .actions {
    display: flex;
    gap: 0.5rem;
    margin-top: 0.5rem;
  }
  button {
    padding: 0.5rem 0.9rem;
    border-radius: 6px;
    border: 1px solid #cbd5e1;
    background: #f1f5f9;
    cursor: pointer;
    font-size: 0.85rem;
  }
  .primary {
    background: #3b82f6;
    color: white;
    border-color: #3b82f6;
  }
  .danger {
    background: #fee2e2;
    color: #b91c1c;
    border-color: #fca5a5;
  }
</style>
