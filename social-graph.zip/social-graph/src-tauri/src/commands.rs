use crate::models::{
    GraphData, NewPerson, NewRelationship, Person, Relationship, UpdatePerson,
    UpdateRelationship,
};
use sqlx::SqlitePool;
use tauri::State;

type Db<'a> = State<'a, SqlitePool>;

// ---------- People ----------

#[tauri::command]
pub async fn list_people(db: Db<'_>) -> Result<Vec<Person>, String> {
    sqlx::query_as::<_, Person>("SELECT id, name, note, color, created_at FROM people ORDER BY name")
        .fetch_all(db.inner())
        .await
        .map_err(|e| e.to_string())
}

#[tauri::command]
pub async fn add_person(db: Db<'_>, payload: NewPerson) -> Result<Person, String> {
    let color = payload.color.unwrap_or_else(|| "#3b82f6".to_string());
    let rec = sqlx::query_as::<_, Person>(
        "INSERT INTO people (name, note, color) VALUES (?, ?, ?)
         RETURNING id, name, note, color, created_at",
    )
    .bind(payload.name)
    .bind(payload.note)
    .bind(color)
    .fetch_one(db.inner())
    .await
    .map_err(|e| e.to_string())?;
    Ok(rec)
}

#[tauri::command]
pub async fn update_person(db: Db<'_>, payload: UpdatePerson) -> Result<Person, String> {
    let rec = sqlx::query_as::<_, Person>(
        "UPDATE people SET name = ?, note = ?, color = ? WHERE id = ?
         RETURNING id, name, note, color, created_at",
    )
    .bind(payload.name)
    .bind(payload.note)
    .bind(payload.color)
    .bind(payload.id)
    .fetch_one(db.inner())
    .await
    .map_err(|e| e.to_string())?;
    Ok(rec)
}

#[tauri::command]
pub async fn delete_person(db: Db<'_>, id: i64) -> Result<(), String> {
    // Beziehungen werden durch ON DELETE CASCADE automatisch mitgelöscht.
    sqlx::query("DELETE FROM people WHERE id = ?")
        .bind(id)
        .execute(db.inner())
        .await
        .map_err(|e| e.to_string())?;
    Ok(())
}

// ---------- Relationships ----------

/// Normalisiert ein Personen-Paar so, dass from_id < to_id gilt.
/// Das hält die UNIQUE-Constraint konsistent, egal in welcher
/// Reihenfolge der Nutzer im Frontend zwei Knoten verbindet.
fn normalize_pair(a: i64, b: i64) -> Result<(i64, i64), String> {
    if a == b {
        return Err("Eine Person kann nicht mit sich selbst verbunden werden".into());
    }
    Ok(if a < b { (a, b) } else { (b, a) })
}

#[tauri::command]
pub async fn list_relationships(db: Db<'_>) -> Result<Vec<Relationship>, String> {
    sqlx::query_as::<_, Relationship>(
        "SELECT id, from_id, to_id, kind, strength, note, created_at FROM relationships",
    )
    .fetch_all(db.inner())
    .await
    .map_err(|e| e.to_string())
}

#[tauri::command]
pub async fn add_relationship(
    db: Db<'_>,
    payload: NewRelationship,
) -> Result<Relationship, String> {
    let (from_id, to_id) = normalize_pair(payload.person_a, payload.person_b)?;

    let rec = sqlx::query_as::<_, Relationship>(
        "INSERT INTO relationships (from_id, to_id, kind, strength, note)
         VALUES (?, ?, ?, ?, ?)
         RETURNING id, from_id, to_id, kind, strength, note, created_at",
    )
    .bind(from_id)
    .bind(to_id)
    .bind(payload.kind)
    .bind(payload.strength)
    .bind(payload.note)
    .fetch_one(db.inner())
    .await
    .map_err(|e| {
        if e.to_string().contains("UNIQUE") {
            "Diese beiden Personen sind bereits verbunden".to_string()
        } else {
            e.to_string()
        }
    })?;
    Ok(rec)
}

#[tauri::command]
pub async fn update_relationship(
    db: Db<'_>,
    payload: UpdateRelationship,
) -> Result<Relationship, String> {
    let rec = sqlx::query_as::<_, Relationship>(
        "UPDATE relationships SET kind = ?, strength = ?, note = ? WHERE id = ?
         RETURNING id, from_id, to_id, kind, strength, note, created_at",
    )
    .bind(payload.kind)
    .bind(payload.strength)
    .bind(payload.note)
    .bind(payload.id)
    .fetch_one(db.inner())
    .await
    .map_err(|e| e.to_string())?;
    Ok(rec)
}

#[tauri::command]
pub async fn delete_relationship(db: Db<'_>, id: i64) -> Result<(), String> {
    sqlx::query("DELETE FROM relationships WHERE id = ?")
        .bind(id)
        .execute(db.inner())
        .await
        .map_err(|e| e.to_string())?;
    Ok(())
}

// ---------- Graph (kombiniert) ----------

/// Liefert Knoten und Kanten in einem einzigen Call, damit das Frontend
/// den Graphen ohne zwei separate Requests aufbauen muss.
#[tauri::command]
pub async fn get_graph(db: Db<'_>) -> Result<GraphData, String> {
    let people = sqlx::query_as::<_, Person>(
        "SELECT id, name, note, color, created_at FROM people ORDER BY name",
    )
    .fetch_all(db.inner())
    .await
    .map_err(|e| e.to_string())?;

    let relationships = sqlx::query_as::<_, Relationship>(
        "SELECT id, from_id, to_id, kind, strength, note, created_at FROM relationships",
    )
    .fetch_all(db.inner())
    .await
    .map_err(|e| e.to_string())?;

    Ok(GraphData {
        people,
        relationships,
    })
}
