use serde::{Deserialize, Serialize};

#[derive(Debug, Serialize, Deserialize, sqlx::FromRow)]
pub struct Person {
    pub id: i64,
    pub name: String,
    pub note: Option<String>,
    pub color: String,
    pub created_at: String,
}

#[derive(Debug, Deserialize)]
pub struct NewPerson {
    pub name: String,
    pub note: Option<String>,
    pub color: Option<String>,
}

#[derive(Debug, Deserialize)]
pub struct UpdatePerson {
    pub id: i64,
    pub name: String,
    pub note: Option<String>,
    pub color: String,
}

#[derive(Debug, Serialize, Deserialize, sqlx::FromRow)]
pub struct Relationship {
    pub id: i64,
    pub from_id: i64,
    pub to_id: i64,
    pub kind: String,
    pub strength: i64,
    pub note: Option<String>,
    pub created_at: String,
}

#[derive(Debug, Deserialize)]
pub struct NewRelationship {
    pub person_a: i64,
    pub person_b: i64,
    pub kind: String,
    pub strength: i64,
    pub note: Option<String>,
}

#[derive(Debug, Deserialize)]
pub struct UpdateRelationship {
    pub id: i64,
    pub kind: String,
    pub strength: i64,
    pub note: Option<String>,
}

/// Kombiniertes Paket für den Graph: alle Knoten + alle Kanten in einem Call,
/// damit das Frontend nicht zwei Requests synchronisieren muss.
#[derive(Debug, Serialize)]
pub struct GraphData {
    pub people: Vec<Person>,
    pub relationships: Vec<Relationship>,
}
